const express = require("express");
const app = express();
const port = 8000;

//----MIDDLEWARE-----///
app.use(express.json()); //interpets jsonobjects
app.use(express.urlencoded({ extended: true }));

const faker = require("@faker-js/faker");


class User {
    constructor() {
        this.firstName = faker.name.firstName();
        this.lastName = faker.name.lastName();
        this.phoneNumber = faker.phone.phoneNumber();
        this.email = faker.internet.email();
        this.password = faker.internet.password();
    }
}

class Company {
    constructor() {
        this.name = faker.company.companyName();
        this.address = {
            street : faker.address.streetName(),
            city : faker.address.cityName(),
            state : faker.address.state(),
            zipCode : faker.address.zipCode(),
            country : faker.address.country()
        }
    }
}


const newUser = new User();

const newCompany = new Company();

//-----ROUTING GET REQUESTS----//
app.get("/api", (requestObj, responseObj) => {
    console.log("hey");
})

app.get("/api/users/new", (req, res) => {
    res.json(newUser)
})

app.get("/api/companies/new", (req, res) => {
    res.json(newCompany)
})

app.get("/api/user/company", (req, res) => {
    res.json({ newUser: newUser, newCompany: newCompany })
})

//------POST REQUEST-----//
app.post("/api/users", (req, res) => {

})


app.listen(port, () => console.log("Server started on port ${port} and is listening for REQuests to RESpond to..."))